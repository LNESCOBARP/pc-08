﻿class semana10_Nicolle_Escobar
{
    static void Main(string[] args)
    {
         int[] numeros = new int[8];
        int suma = 0;

        Console.WriteLine("Ingrese 8 números");
        for (int i = 0; i < numeros.Length; i++)
        {
            Console.Write(i + 1 +".");
            numeros[i] = int.Parse(Console.ReadLine());
            suma += numeros[i];
        }
        Console.WriteLine("Los números ingresados son:");
        foreach (int numero in numeros)
        {
            Console.WriteLine(numero);
        }
        Console.WriteLine("La suma es: " + suma);

        double promedio = (double)suma / numeros.Length;
        Console.WriteLine("El promedio es: " + promedio);

        Console.ReadKey();
    }
}