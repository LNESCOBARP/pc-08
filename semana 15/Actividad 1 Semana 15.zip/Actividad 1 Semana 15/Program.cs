﻿public class Estudiante
{ 
    string Nombre;
    int edad;
    string carrera;
    string carnet;
    double Notadmision;
    public Estudiante (string Nombre, string carrera)
    {
        this.Nombre = Nombre;
        this.edad = 0;
        this.carrera = carrera;
        this.carnet = "";
        this.Notadmision = 0;
    }
    public void MostrarResumen()
    {
        Console.WriteLine($"Su Nombre es: {this.Nombre}");
        Console.WriteLine($"Su edad es: {this.edad}");
        Console.WriteLine($"Su carrera es: {this.carrera}");
        Console.WriteLine($"Su carnet es: {this.carnet}");
        Console.WriteLine($"Su nota de Admisión es: {this.Notadmision}");
        
    }
     public bool PuedeMatricular() 
    {
        return this.Notadmision >= 75;   
    }

      public static void Main(string[] args)
    {
        
        Console.WriteLine("Bienvenid@ a la prueba de admisión");
        Console.WriteLine("Ingrese su Nombre: ");
        String Nombre = Console.ReadLine();
        Console.WriteLine("Carrera que desea entrar: ");
        String carrera = Console.ReadLine();

        Estudiante estudiante = new Estudiante(Nombre, carrera);

        Console.WriteLine("Ingrese su edad");
        estudiante.edad = int.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese el carnet del estudiante:");
        String carnetInput = Console.ReadLine();
        estudiante.carnet = carnetInput + "2025";
        Console.WriteLine("Ingrese su nota de admisión del estudiante:");
        estudiante.Notadmision = double.Parse(Console.ReadLine());

        estudiante.MostrarResumen();
        if (estudiante.PuedeMatricular())
        {
            Console.WriteLine("Si puede Matricularse, Felicidades");
        }
        else
        {
            Console.WriteLine("No cumples con los requisitos de para pode matricularte");
            Console.WriteLine("pero no te rindas la proxima tu podras hacerlo");
        }
    }
}