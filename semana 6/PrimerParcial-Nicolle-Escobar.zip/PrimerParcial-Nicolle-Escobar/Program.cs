﻿class semana6
{
    public static void Main(string[] args)
    {
        double x,y;

        Console.WriteLine("Escriba 1 número: ");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Escriba otro número: ");
        double b = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Escriba otra vez un número: ");
        double c = Convert.ToDouble(Console.ReadLine());

        if
        (a>b)
       if (a > c)
       if (b>c)
       if (b>a)
       if (c % 2==0);
       
        else
        {
            int.Parse('mayor'+ a + 'menor'+ b);
        }
       }
       }
       