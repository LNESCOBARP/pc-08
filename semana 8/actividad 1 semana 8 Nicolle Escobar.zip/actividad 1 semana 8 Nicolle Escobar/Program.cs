﻿using System.Security.Cryptography.X509Certificates;
class Semana8_Actividad1
{
    static void Main()
    {
        Console.WriteLine("Ingrese un número entero: ");
        if (int.TryParse(Console.ReadLine(), out int numero) && numero > 0)
        {
            int factorial = CalcularFactorial(numero);
            Console.WriteLine("El factorial es: " + factorial);
        }
        else
        {
            Console.WriteLine("Ingrese un número válido.");
        }
    }

    public static int CalcularFactorial(int numero)
    {
        if (numero == 0)
        {
            return 1;
        }
        else
        {
            int factorial = 1;
            for (int i = 1; i <= numero; i++)
            {
                factorial *= i;
            }
            return factorial;
        }
    }
}