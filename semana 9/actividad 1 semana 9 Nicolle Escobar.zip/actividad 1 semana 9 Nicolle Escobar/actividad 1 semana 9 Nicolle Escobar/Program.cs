﻿class Semana9_actividad1
{
    static void Main(string[] args)
    {
        
        Console.WriteLine("Ingrese un número entero: ");
        int N;

        if (int.TryParse(Console.ReadLine(), out N) && N > 0 && N <= 999999)
        {
            bool esPrimo = true;

            if (N == 1)
            {
                esPrimo = false;
            }
            else
            {
                for (int C = 2; C <= Math.Sqrt(N); C++) 
                {
                    if (N % C == 0)
                    {
                        esPrimo = false;
                        break;
                    }
                }
            }
            if (esPrimo)
            {
                Console.WriteLine($"El número {N} es primo.");
            }
            else
            {
                Console.WriteLine($"El número {N} no es primo.");
            }
        }
        else
        {
            Console.WriteLine("El número ingresado no es válido. Por favor, ingrese un número positivo de 6 cifras.");

     }
    }
}